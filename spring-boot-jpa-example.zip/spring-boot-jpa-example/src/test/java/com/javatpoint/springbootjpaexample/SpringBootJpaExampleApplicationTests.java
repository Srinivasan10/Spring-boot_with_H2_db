package com.javatpoint.springbootjpaexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJpaExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
